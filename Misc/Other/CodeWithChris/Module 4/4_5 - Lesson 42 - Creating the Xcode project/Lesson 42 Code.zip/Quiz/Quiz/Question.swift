//
//  Question.swift
//  Quiz - A single question in our quiz
//
//
//
//

import UIKit

class Question: NSObject {

    
    var questionText:String = "";
    
    var answers:[String] = [String]();
    
    var correctAnswerIndex:Int = 0;
    
    var module:Int = 0;
    
    var lesson:Int = 0;
    
    var feedback:String = "";
    
}


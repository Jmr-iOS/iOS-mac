//
//  QuizModel.swift
//  Quiz
//
//

import UIKit;

class QuizModel: NSObject {

    
    func getQuestions() -> [Question] {
        
        //Questions to return
        var questions:[Question] = [Question]();
        
        //Fet Json file and array of dictionaries
        let jsonObjects:[NSDictionary] = self.getLocalJsonFile();
        
        //@todo Loop through each dictionary and assign values to our question onjects
        for (var index:Int = 0; index < jsonObjects.count; index++) {
    
            //Current JSON Dict
            let jsonDictionary:NSDictionary = jsonObjects[index];
            
            //Create a Q Obj
            let q:Question = Question();
            
            //Assign a key-value pair
            q.questionText = jsonDictionary["question"] as! String;
            
            q.answers = jsonDictionary["answers"] as! [String];
            q.correctAnswerIndex = jsonDictionary["correctIndex"] as! Int;
            q.module   = jsonDictionary["module"] as! Int;
            q.lesson   = jsonDictionary["lesson"] as! Int;
            q.feedback = jsonDictionary["feedback"] as! String;
            
            //Add it!
            questions.append(q);
            
            print("  Question (\(q.questionText)) appended");
        }
        
        //Return the array of questions
        return questions;
    }
    
    
    func getLocalJsonFile() -> [NSDictionary] {
        
        //Get an NSURL object pointing to the JSON file in our app bundle
        let appBundlePath:String? = NSBundle.mainBundle().pathForResource("QuestionData", ofType: "json");
        
        if let actualBundlePath = appBundlePath {

            //Path exists
            let urlPath:NSURL = NSURL(fileURLWithPath: actualBundlePath);
            
            let jsonData:NSData? = NSData(contentsOfURL: urlPath);
            
            if let actualJsonData = jsonData {
            
                // NSData Exists, use the NSJSONSerialization classses and parse the data & create the dicts
                
                do {
                    let arrayOfDictionaries:[NSDictionary] = try NSJSONSerialization.JSONObjectWithData(actualJsonData, options: NSJSONReadingOptions.MutableContainers) as! [NSDictionary];
                    
                    print(">>>New Dictionary Size:\(arrayOfDictionaries.count)");
                    
                    return arrayOfDictionaries;
                } catch {
                        //File parsing error
                }
            } else {
                // NSData doesn't exist
            }
        } else {
            //File path doesn't work
        
        }
        
        return [NSDictionary]();
    }
}


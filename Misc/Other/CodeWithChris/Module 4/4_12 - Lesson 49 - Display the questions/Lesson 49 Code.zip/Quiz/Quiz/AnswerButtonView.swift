//
//  AnswerButtonView.swift
//  Quiz
//
//  Created by Justin Reina on 12/8/15.
//  Copyright © 2015 Christopher Ching. All rights reserved.
//

import UIKit

class AnswerButtonView: UIView {
    
    let answerLabel: UILabel = UILabel();
    
    override init(frame: CGRect) {
        super.init(frame: frame);
    
        //init label
        self.addSubview(self.answerLabel);

        self.answerLabel.translatesAutoresizingMaskIntoConstraints = false;
        
        
        
        return;
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("oops");
    }
    
    func setAnswerText(text:String) {
        
        self.answerLabel.text = text;
        
        self.answerLabel.numberOfLines = 0;
        
        self.answerLabel.textColor = UIColor.whiteColor();
        
        self.answerLabel.textAlignment = NSTextAlignment.Center;
        
        self.answerLabel.adjustsFontSizeToFitWidth = true;
        
        //Set Constraints
        let leftMarginConstrain = NSLayoutConstraint(item: self.answerLabel, attribute: NSLayoutAttribute.Left,
            relatedBy: NSLayoutRelation.Equal, toItem: self, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 20);

        let rightMarginConstrain = NSLayoutConstraint(item: self.answerLabel, attribute: NSLayoutAttribute.Right,
            relatedBy: NSLayoutRelation.Equal, toItem: self, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: -20);
        
        let topMarginConstrain = NSLayoutConstraint(item: self.answerLabel, attribute: NSLayoutAttribute.Top, relatedBy: NSLayoutRelation.Equal, toItem: self, attribute: NSLayoutAttribute.Top, multiplier: 1, constant: 5);

        let bottomMarginConstrain = NSLayoutConstraint(item: self.answerLabel, attribute: NSLayoutAttribute.Bottom, relatedBy: NSLayoutRelation.Equal, toItem: self, attribute: NSLayoutAttribute.Bottom, multiplier: 1, constant: -5);

        self.addConstraints([leftMarginConstrain, rightMarginConstrain, topMarginConstrain, bottomMarginConstrain]);
        
        return;
    }

}

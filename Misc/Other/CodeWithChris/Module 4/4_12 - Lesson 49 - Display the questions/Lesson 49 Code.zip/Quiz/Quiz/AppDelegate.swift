//
//  AppDelegate.swift
//  Quiz
//
//  Created by Christopher Ching on 2015-10-28.
//  Copyright © 2015 Christopher Ching. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        return true;
    }

    func applicationWillResignActive(application: UIApplication) {
        return;
    }

    func applicationDidEnterBackground(application: UIApplication) {
        return;
    }

    func applicationWillEnterForeground(application: UIApplication) {
        return;
    }

    func applicationDidBecomeActive(application: UIApplication) {
        return;
    }

    func applicationWillTerminate(application: UIApplication) {
        return;
    }
}


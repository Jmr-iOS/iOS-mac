//
//  ViewController.swift
//  Quiz
//
//  //@note  Size Class is the size of the device screen size and orientation. It's the wAny hAny at the bottom of the storyboard
//  //@note  Storyboard elements are active only for the specified Size Classes. It allows for items per size and device!

import UIKit;

class ViewController: UIViewController {

    
    let model:QuizModel = QuizModel();
    
    var question:[Question] = [Question]();
    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        self.question = self.model.getQuestions();
        
        return;
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning();
        
        return;
    }
}


//
//  AppDelegate.swift
//  Quiz
//
//

import UIKit;

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        return true;
    }

    func applicationWillResignActive(application: UIApplication) {
        return;
    }

    func applicationDidEnterBackground(application: UIApplication) {
        return;    }

    func applicationWillEnterForeground(application: UIApplication) {
        return;
    }

    func applicationDidBecomeActive(application: UIApplication) {
        return;
    }

    func applicationWillTerminate(application: UIApplication) {
        return;
    }
}


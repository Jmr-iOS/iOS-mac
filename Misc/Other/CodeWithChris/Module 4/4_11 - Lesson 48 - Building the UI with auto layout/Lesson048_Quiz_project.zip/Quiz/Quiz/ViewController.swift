//
//  ViewController.swift
//  Quiz
//
//  Created by Christopher Ching on 2015-10-28.
//  Copyright © 2015 Christopher Ching. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var scrollViewContentView: UIView!
    @IBOutlet weak var moduleLabel: UILabel!
    @IBOutlet weak var questionLabel: UILabel!
    
    let model:QuizModel = QuizModel()
    var question:[Question] = [Question]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Get the questions from the quiz model
        self.question = self.model.getQuestions()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


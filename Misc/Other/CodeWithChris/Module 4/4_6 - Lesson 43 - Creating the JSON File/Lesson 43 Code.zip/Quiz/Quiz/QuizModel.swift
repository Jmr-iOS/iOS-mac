//
//  QuizModel.swift
//  Quiz
//
//

import UIKit;

class QuizModel: NSObject {

    
    func getQuestions() -> [Question] {
        
        //Questions to return
        
        //@todo Get Json file
        
        //@todo Parse the Json file
        
        //@todo Return the list of questions
        
        
        return [Question]();
    }
}


//
//  ViewController.swift
//  Quiz
//
//

import UIKit;

class ViewController: UIViewController {

    
    let model:QuizModel = QuizModel();
    
    var question:[Question] = [Question]();
    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        self.question = self.model.getQuestions();
        
        return;
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning();
        
        return;
    }
}


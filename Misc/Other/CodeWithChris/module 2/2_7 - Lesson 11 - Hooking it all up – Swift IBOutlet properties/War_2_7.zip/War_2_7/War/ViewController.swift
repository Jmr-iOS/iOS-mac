//
//  ViewController.swift
//  War
//
//  Created by Justin Reina on 10/30/15.
//  Copyright © 2015 CodeWithChris. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var firstCardImageView:  UIImageView!
    @IBOutlet weak var secondCardImageView: UIImageView!
    @IBOutlet weak var playAroundButton:    UIButton!
    @IBOutlet weak var backgroundImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        print("View did load. Yup!")
        
        self.playAroundButton.setTitle("Meow?", forState:UIControlState.Normal)
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }



}


//  ViewController.swift
//  War

import UIKit

//@note  Once you get comfortable with Swift and UIKit, you don't need to use storyboards. You can just programatically create them!
//@todo  THIS
class ViewController: UIViewController {
    
    @IBOutlet weak var firstCardImageView:  UIImageView!
    @IBOutlet weak var secondCardImageView: UIImageView!
    @IBOutlet weak var playAroundButton:    UIButton!
    @IBOutlet weak var backgroundImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        print("View did load. Yup!")
    
        self.playAroundButton.setTitle("Meow?", forState:UIControlState.Normal)
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    @IBAction func PlayRoundTapped(sender: UIButton) {
    
        print("Meow?")
        
    }
}


/************************************************************************************************************************************/
/** @file		TimerCell.swift
 *	@project    MultiTimer
 * 	@brief		x
 * 	@details	x
 *
 * 	@author		Justin Reina, Firmware Engineer, Vioteq
 * 	@created	1/6/16
 * 	@last rev	x
 *
 *
 * 	@notes		x
 *
 * 	@section	Opens
 * 			none current
 *
 * 	@section	Legal Disclaimer
 * 			All contents of this source file and/or any other Vioteq related source files are the explicit property on Vioteq
 * 			Corporation. Do not distribute. Do not copy.   Copyright © 2016 Jaostech. All rights reserved.
 */
/************************************************************************************************************************************/
import UIKit
import Foundation  /*for math */


class TimerCell : UITableViewCell {
    
    //State
    var activeTime : TimeLogValue!;             //when nil these mean 'not in use'
    var timeLog    : [TimeLogValue]!;
    
    var timerName : String!;
    
    var nameLabel       : UILabel!;
    var activeTimeLabel : UILabel!;
    var arrowTapArea    : UIView!;
    
    var activityIndicator : UIActivityIndicatorView!;
    
    var activeTimeFont  : UIFont!;
    
    var updateThread : NSTimer!;
    
    var mainView  : UIView!;
    
    
    var activeFrame : CGRect!;
    var nameFrame   : CGRect!;
    
    
    let fontName : String = "AvenirNext-Regular";
    
    let activeFontSize : CGFloat = 40;
    let activeYOffs    : CGFloat = 0;
    
    let activeHeight : CGFloat = globals.tableRowHeight;
    
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style:style, reuseIdentifier:reuseIdentifier);
        
        if(verbose){ print("TimerCell.init():                      the TimerCell was initialized"); }
        
        //init as nil (empty)
        self.activeTime = nil;
        self.timeLog    = nil;
        
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.width, globals.tableRowHeight);
        
        
        return;
    }
    

    /********************************************************************************************************************************/
    /*	@fcn		isRunning() -> Bool                                                                                             */
    /********************************************************************************************************************************/
    func isRunning() -> Bool {
        
        if(self.activeTime == nil) {
            return false;
        }
        
        if(self.activeTime.start == nil) {
            return false;
        }
        
        if(self.activeTime.start != nil) && (self.activeTime.end != nil) {
            return false;
        }
        
        return true;
    }
    func initialize(timerName:String, mainView : UIView) {
        
        //------store------//
        self.timerName = timerName;
        self.mainView  = mainView;
        
        self.selectionStyle = UITableViewCellSelectionStyle.None;
        
        self.activeTimeFont = UIFont(name: fontName, size: activeFontSize)!;
        
        self.activeFrame = CGRectMake(0, activeYOffs, UIScreen.mainScreen().bounds.width, activeHeight);

        self.nameFrame   = CGRectMake(globals.cellNameXOffs, activeYOffs, UIScreen.mainScreen().bounds.width, activeHeight);
        
        /****************************************************/
        /*         Name        (nameLabel)                  */
        /****************************************************/
        nameLabel = UILabel(frame: nameFrame);
        
        nameLabel.text = timerName;
        
        nameLabel.textAlignment = NSTextAlignment.Left;
        
        
        self.addSubview(nameLabel);
        
        
        /****************************************************/
        /*         Active Time (activeTimeLabel)            */
        /****************************************************/
        activeTimeLabel = UILabel(frame: activeFrame);
        
        //font
        activeTimeLabel.font = self.activeTimeFont;
        activeTimeLabel.textColor = globals.stoppedColor;
        
        //layout
        activeTimeLabel.textAlignment = .Left;
        activeTimeLabel.numberOfLines = 1;
        
        
        var newActiveTimeCenter : CGPoint = activeTimeLabel.center;

        newActiveTimeCenter.x = newActiveTimeCenter.x + globals.activeTimeXOffs; //180
        
        activeTimeLabel.center = newActiveTimeCenter;
        
        //Text & Add
        activeTimeLabel.text = "00:00.00";
        
        self.addSubview(activeTimeLabel);
        
        /****************************************************/
         /*         Menu arrow                               */
         /****************************************************/

        let arrowTapFrame :CGRect = CGRectMake(0,0,globals.arrowTapWidth,self.frame.height);
        
        arrowTapArea = UIView(frame:arrowTapFrame);
        let arrowImgView : UIImageView = UIImageView(image: UIImage(named:"arrow2"));
        
        let arrowImgFrame : CGRect = CGRectMake(12, 26, arrowImgView.frame.width/1.75, arrowImgView.frame.height/1.75);
        arrowImgView.frame = arrowImgFrame;
        
        let tapGesture = UITapGestureRecognizer(target: self, action: Selector("arrowPressed:"));
        tapGesture.delegate = self;
        
        arrowTapArea.addGestureRecognizer(tapGesture);
        arrowTapArea.addSubview(arrowImgView);
        
        self.addSubview(arrowTapArea);
        
        /****************************************************/
        /*       updateThread & activityIndicator           */
        /****************************************************/
        //create & start the timer
        updateThread = NSTimer.scheduledTimerWithTimeInterval(globals.cellUpdatePeriod_s, target: self, selector: "updateTimerText", userInfo: nil, repeats: true);

        //create the activity indicator
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .Gray);
        
        activityIndicator.center = CGPoint(x: globals.activityIndXOffs, y: 37);
        
        
        self.addSubview(activityIndicator);
        
        if(verbose){ print("TimerCell.initialize():                the TimerCell is running"); }
        
        return;
    }
    
    
    func updateTimerText() {
        
        var displayStr :String = "00:00.00";

        //get the total time
        let totalDur : TimeLogValue = TimeLogValue.calcTotal(self.activeTime, vals: self.timeLog);
        
        if(totalDur.getTime_s() > 0) {

            let total : TimeValue = totalDur.getTimeForPrint();

            displayStr = String(format: "%.2d:%.2d.%.2d", total.minutes, total.seconds, total.milliseconds/10);       //div by 10 for 2 digs
        }
     
        activeTimeLabel.text = displayStr;
        
        return;
    }
    
    
    func startRunning() {

        //create a new activeTime and start it
        self.activeTime = TimeLogValue();
        self.activeTime.startTimeLogValue();
        
        //display blue and ticking
        self.activityIndicator.startAnimating();
        
        self.activeTimeLabel.textColor     = globals.runningColor;
        self.activityIndicator.color       = globals.runningColor;
        
        return;
    }
    
    
    func stopRunning() {
        
        if(self.timeLog == nil) {
            self.timeLog = [TimeLogValue]();            //init if nil
        }
        
        
        //stop it, store it and clear the var
        if(self.activeTime != nil) {
            self.activeTime.stopTimeLogValue();
        }
        
        self.timeLog.append(self.activeTime);
        self.activeTime = nil;

        activityIndicator.stopAnimating();

        activeTimeLabel.textColor = globals.stoppedColor;
        activityIndicator.color   = globals.stoppedColor;
        
        return;
    }
    
    
    func toggleTimer() {
        
        
        if(self.isRunning()) {
            self.stopRunning();    /* it's on, turn it off */
        } else {
            self.startRunning();   /* it's off, turn it on */
        }
        
        
        if(verbose){ print("TimerCell.toggleTimer():               toggled"); }
        
        return;
    }

    
    func clearTimer() {
        
        if(self.activeTime != nil) {
            self.activeTime.start = NSDate(timeIntervalSinceNow: 0);
        }
        
        self.timeLog    = nil;        
        
        return;
    }

    
    func resetTimer() {

        self.stopRunning();
        
        self.clearTimer();
        
        return;
    }
    
    
    
    
    func arrowPressed(sender : UIButton!) {
        
        if(verbose){ print("TimerCell.arrowPressed():           launching subview"); }
        
        //launch subscreen
        let newScr : TimerSubview = TimerSubview(frame:UIScreen.mainScreen().bounds, cell: self);
        
        mainView.addSubview(newScr);
        
        return;
    }


    func setArrowState(arrowNewState : Bool) {  /* On/Off */
        
        self.arrowTapArea.subviews[0].alpha = (arrowNewState) ? 1.0 : 0.0;
        
        return;
    }
    
    
    //take the curr timer time and move it over into elapsed_dur
    func updateTimeElapsed() {

        print("EWWW!!!!!EWWW!!!!!EWWW!!!!!EWWW!!!!!EWWW!!!!!EWWW!!!!!EWWW!!!!!EWWW!!!!!EWWW!!!!!EWWW!!!!!EWWW!!!!!EWWW!!!!!EWWW!!!!!EWWW!!!!!EWWW!!!!!EWWW!!!!!EWWW!!!!!");
        
        return;
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


/************************************************************************************************************************************/
/** @file		SubviewTableView.swift
 *	@project    MultiTimer
 * 	@brief		x
 * 	@details	x
 *
 * 	@author		Justin Reina, Firmware Engineer, Vioteq
 * 	@created	1/11/16
 * 	@last rev	x
 *
 *
 * 	@notes		x
 *
 * 	@section	Opens
 * 			none current
 *
 * 	@section	Legal Disclaimer
* 			All contents of this source file and/or any other Vioteq related source files are the explicit property on Vioteq
* 			Corporation. Do not distribute. Do not copy.   Copyright © 2016 Jaostech. All rights reserved.
 */
/************************************************************************************************************************************/
import UIKit


class SubviewTableView : UITableView, UITableViewDataSource, UITableViewDelegate {
    
    
    var parentCell : TimerCell!;
    
    var myCells : [UITableViewCell] = [UITableViewCell]();
    

    init(frame: CGRect, style: UITableViewStyle, parentCell : TimerCell) {
        super.init(frame: frame, style : style);
      
        self.registerClass(UITableViewCell.self, forCellReuseIdentifier: "cell");
        
        self.translatesAutoresizingMaskIntoConstraints = false;

        var timeLog : [TimeLogValue]! = parentCell.timeLog;
        
        if(timeLog != nil) {
            //Load the time values into individ cells
            for i in 0...(timeLog.count-1) {
            
                let newCell  = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "");
                let total    = timeLog[i].getTimeForPrint();
                let timeText = String(format: "%.2d:%.2d.%.2d", total.minutes, total.seconds, total.milliseconds/10);       //div by 10 for 2 digs
            
                newCell.textLabel?.text = timeText;
                myCells.append(newCell);
            }
        }
        
        
        //setup data
        self.delegate   = self;
        self.dataSource = self;
        
        //init the table
        self.separatorColor = .grayColor();
        self.separatorStyle = .SingleLine;
        
        //Safety
        self.backgroundColor = UIColor.blackColor();
        
        //Set the row height
        self.rowHeight = 75;

        return;
    }


    func clearCells() {
    
        self.myCells = [UITableViewCell]();
    
        return;
    }
    
    
/************************************************************************************************************************************/
/*                                      UITableViewDataSource, UITableViewDelegate Interfaces                                       */
/************************************************************************************************************************************/
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if(verbose){ print("SubviewTableView():         The table will now have \(myCells.count), cause I just said so..."); }
        
        return myCells.count;                                                         //return how many rows you want printed....!
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if(verbose){ print("SubviewTableView():         adding a cell"); }
        
        return myCells[indexPath.item];
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        if(verbose){ print("SubviewTableView():         handling a cell tap of \(indexPath.item)"); }
        
        self.deselectRowAtIndexPath(indexPath, animated:true);
        
        return;
    }

    
    required init?(coder aDecoder: NSCoder) { fatalError("init(coder:) has not been implemented"); }
}


/************************************************************************************************************************************/
/** @file		TimerSubview.swift
 *	@project    MultiTimer
 * 	@brief		x
 * 	@details	x
 *
 * 	@author		Justin Reina, Firmware Engineer, Vioteq
 * 	@created	1/6/16
 * 	@last rev	x
 *
 *
 * 	@notes		x
 *
 * 	@section	Opens
 * 			none current
 *
 * 	@section	Legal Disclaimer
 * 			All contents of this source file and/or any other Vioteq related source files are the explicit property on Vioteq
 * 			Corporation. Do not distribute. Do not copy.   Copyright © 2016 Jaostech. All rights reserved.
 */
/************************************************************************************************************************************/
import UIKit



class TimerSubview : UIView, UIGestureRecognizerDelegate {
    
    var parentCell : TimerCell!;

    var clearButton  : UIButton!;
    var returnButton : UIButton!;
    
    
    var aLabel : UILabel!;

    var logTable : SubviewTableView!;

    var updateThread : NSTimer!;

    
    init(frame: CGRect, cell: TimerCell) {
        super.init(frame:frame);
            
        self.parentCell = cell;
        
        self.backgroundColor = UIColor.whiteColor();                /* else background is transparent                               */

        self.initClearButton();
        self.initReturnButton();
        self.initActiveTimer();
        self.initTableNew();
        
        return;
    }
    

    func initClearButton() {
    
        let dims : SubviewButtonDims = globals.subviewButtonDims;
        
        //add
        clearButton = UIButton(type: UIButtonType.RoundedRect);
        clearButton.translatesAutoresizingMaskIntoConstraints = true;                                  //must be true for center to work
        clearButton.setTitle("Clear",      forState: UIControlState.Normal);
        clearButton.sizeToFit();
        clearButton.center = CGPointMake(dims.clearCenterX, dims.clearCenterY);
        clearButton.addTarget(self, action: "clearPressed:", forControlEvents:  .TouchUpInside);
        
        self.addSubview(clearButton);
        
        return;
    }
    
    
    func initReturnButton() {

        let dims : SubviewButtonDims = globals.subviewButtonDims;

        returnButton = UIButton(type: UIButtonType.RoundedRect);
        returnButton.translatesAutoresizingMaskIntoConstraints = true;                                  //must be true for center to work
        returnButton.setTitle("Return",      forState: UIControlState.Normal);
        returnButton.sizeToFit();
        returnButton.center = CGPointMake(dims.returnCenterX, dims.returnCenterY);
        returnButton.addTarget(self, action: "returnPressed:", forControlEvents:  .TouchUpInside);
        
        self.addSubview(returnButton);

        return;
    }
    
    
    func initActiveTimer() {
    
        let activeTime : TimeLogValue!   = self.parentCell.activeTime;
        var timeLog    : [TimeLogValue]! = self.parentCell.timeLog;
        if(timeLog==nil) { timeLog = [TimeLogValue](); }
        
        
        //ActiveTimer
        let aSize = globals.aSubFrameSubSize;
        let aFont = globals.aSubFrameFont//UIFont(name: "?", size:globals.aFrameFontSize);
        
        let aFrame : CGRect = CGRectMake(aSize.xOffs, aSize.yOffs, aSize.width, aSize.height);
        
        
        self.aLabel = UILabel(frame: aFrame);
        
        self.aLabel.font = aFont;
        self.aLabel.textAlignment = .Center;
        
        if(activeTime != nil) {
            aLabel.text = TimeLogValue.getPrintString(TimeLogValue.getTimeForPrint(activeTime)());
        } else {
            aLabel.text = "00:00:00";
        }
        
        self.aLabel.numberOfLines = 1;
        
        self.aLabel.sizeToFit();

        self.addSubview(aLabel);
        
        //Update Thread - create & start the timer
        self.updateThread = NSTimer.scheduledTimerWithTimeInterval(globals.cellUpdatePeriod_s, target: self, selector: "updateActiveTimeLabel", userInfo: nil, repeats: true);

        return;
    }

    
    func initTableNew() {
        let tempBarHeight : CGFloat = 75;
        
        let tempFrame : CGRect = CGRectMake(0,
                                            globals.titleBarYOffs + globals.titleBarHeight + 25,
                                            UIScreen.mainScreen().bounds.width,
                                            UIScreen.mainScreen().bounds.height - tempBarHeight);

        self.logTable = SubviewTableView(frame: tempFrame, style: UITableViewStyle.Plain, parentCell:  self.parentCell);
        
        self.logTable.backgroundColor = UIColor.grayColor();

        
        self.addSubview(self.logTable);
        
        print("log table was added to the view");
        
        return;
    }
    
    
    func clearPressed(sender: UIButton!) {
        
        parentCell.clearTimer();
    
        
        if(self.logTable != nil) {
            self.logTable.clearCells();
            self.logTable.reloadData();
        }
        
    
        if(verbose) { print("\(sender.titleLabel!.text!) was pressed"); }

        return;
    }
    
    
    func returnPressed(sender: UIButton!) {
        
        self.removeFromSuperview();
        
        if(verbose) { print("\(sender.titleLabel!.text!) was pressed"); }

        return;
    }
    
    func arrowPressed(sender: UIButton!) {
        
        self.removeFromSuperview();
        
        if(verbose) { print("\(sender.titleLabel!.text!) was pressed"); }
        
        return;
    }

    
    func updateActiveTimeLabel() {
        
        var displayStr : String = "00:00:00";
        let activeTime = self.parentCell.activeTime;
        
        if(activeTime != nil) {

            let currTime : TimeValue = activeTime.getTimeForPrint();

            displayStr = TimeLogValue.getPrintString(currTime);

            self.aLabel.textColor = (activeTime.isRunning()) ? globals.runningColor : globals.stoppedColor;
        }
        
        self.aLabel.text = displayStr;

        
        return;
    }
        
    
    required init?(coder aDecoder: NSCoder) { fatalError("init(coder:) has not been implemented"); }
}


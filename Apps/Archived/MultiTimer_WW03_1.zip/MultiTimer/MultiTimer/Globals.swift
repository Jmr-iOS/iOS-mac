/************************************************************************************************************************************/
 /** @file		Globals.swift
 *	@project    MultiTimer_NEW
 *
 * 	@author		Justin Reina, Firmware Engineer, Vioteq
 * 	@created	1/4/16
 *
 * 	@section	Opens
 * 			none current
 *
 * 	@section	Legal Disclaimer
 * 			All contents of this source file and/or any other Vioteq related source files are the explicit property on Vioteq
 * 			Corporation. Do not distribute. Do not copy.   Copyright © 2016 Jaostech. All rights reserved.
 */
/************************************************************************************************************************************/

import UIKit

let numItems_init  : Int = 4;

let verbose : Bool = true;

let globals   : Globals = Globals();

let DISP_AS_MIN_SEC  : Bool = true;     //useful during dev

let NUM_SEC_IN_YEAR  : Int =  60*60*24*365;
let NUM_SEC_IN_MONTH : Int = (60*60*24*365)/12;
let NUM_SEC_IN_DAY   : Int =  60*60*24;
let NUM_SEC_IN_HOUR  : Int =  60*60;
let NUM_SEC_IN_MINUTE: Int =  60;
let NUM_SEC_IN_SECOND: Int =  1;    //;)...
let NUM_MS_IN_SECOND : Int =  1000;

let NUM_MONTHS_IN_YEAR    : Int = 12;
let NUM_DAYS_IN_MONTH_MAX : Int = 31;
let NUM_HOURS_IN_DAY      : Int = 24;
let NUM_MIN_IN_HOUR       : Int = 60;
let NUM_SEC_IN_MIN        : Int = 60;


//text deets
let cellFontName : String = "AvenirNext-Regular";



struct TimerCellValue {
    
    var totalDur_s  : CGFloat = 0;
    var years       : Int     = 0;
    var months      : Int     = 0;
    var days        : Int     = 0;
    var hours       : Int     = 0;
    var minutes     : Int     = 0;
    var seconds     : Int     = 0;
    var milliseconds: Int     = 0;
}

class Globals : NSObject {
    
    //text colors
    let runningColor : UIColor = UIColor(red:  53/255, green: 151/255, blue: 218/255, alpha: 1.0);
    let stoppedColor : UIColor = UIColor(red:   0/255, green:   0/255, blue: 0/255,   alpha: 1.0);
    
    let timerTableYOffs : CGFloat = 15;
    
    let titleBarYOffs  : CGFloat = 20;
    let titleBarHeight : CGFloat = 40;
    
    let addLabelXOffs  : CGFloat = UIScreen.mainScreen().bounds.width-30;
    let addLabelYOffs  : CGFloat = 26;
    
    let remLabelXOffs  : CGFloat = -20;
    let remLabelYOffs  : CGFloat = 26;
    
    let arrowTapWidth  : CGFloat = 50;
    
    let tableRowHeight  : CGFloat = 75;
    
    let subviewButtYOffs : CGFloat = 75;
    
    let titleFontSize : CGFloat = 20;
    let addFontSize   : CGFloat = 30;
    let remFontSize   : CGFloat = 18;
    
    let magicTableHeightMod : CGFloat = 0.9;
    
    let mainTableScrollEnabled : Bool = true;
    
    let titleBarFont = UIFont.systemFontOfSize(24);
    
    var activeTimeXOffs  : CGFloat = 180;
    var activityIndXOffs : CGFloat = UIScreen.mainScreen().bounds.width - 17;
    
    let cellNameXOffs : CGFloat = 50;
    
    let cellUpdatePeriod_s : Double = 0.07;

//**********************************************************************************************************************************//
//                                                      SubView Globals                                                             //
//**********************************************************************************************************************************//
    var aSubFrameSubSize : stdDims = stdDims(xOffs:  UIScreen.mainScreen().bounds.width/2 - 77,      /*Active Time Label in the Subview  */
                                             yOffs:  20,
                                             width:  0,
                                             height: 0);

    
    var aSubFrameFont = UIFont(name: "AvenirNext-Regular", size: 40);
    
    var subviewButtonDims : SubviewButtonDims = SubviewButtonDims(clearCenterX:  UIScreen.mainScreen().bounds.width - 35,
                                                                  clearCenterY:  35,        //I have no idea why these all look good at 35 ;-0...
                                                                  returnCenterX: 35,
                                                                  returnCenterY: 35);
    
    /********************************************************************************************************************************/
    /*	@fcn		override init()                                                                                                 */
    /********************************************************************************************************************************/
    override init() {
        super.init();

        //(todo) make an App Setting to check too!
        let dispIsZoomed : Bool = (UIDevice.currentDevice().name == "Justin's iPhone");
        
        var zoomStat : String = "Globals.init():                        I am not zoomed";
        
        //setup screen size (display zoom has different pixel count!)
        if(dispIsZoomed) {
            
            activeTimeXOffs  = 125;
            activityIndXOffs = UIScreen.mainScreen().bounds.width - 17;

            zoomStat = "Globals.init():                        I am zoomed";
        }
        
        if(verbose) { print(zoomStat); }
        
        return;
    }
    
    
    //for debug & dev
    var tempNum : Int = 0;
    
    func getTempNum() -> Int {
        return tempNum++;
    }
}

struct stdDims {
    var xOffs : CGFloat!;
    var yOffs : CGFloat!;
    var width : CGFloat!;
    var height: CGFloat!;
}

struct SubviewButtonDims {
    var clearCenterX : CGFloat!;
    var clearCenterY : CGFloat!;
    var returnCenterX : CGFloat!;
    var returnCenterY : CGFloat!;

}


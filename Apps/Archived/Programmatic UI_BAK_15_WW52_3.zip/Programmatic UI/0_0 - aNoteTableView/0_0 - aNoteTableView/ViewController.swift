//
//  ViewController.swift
//  TableView Example
//
//  URL:  http://viperxgames.blogspot.com/2014/11/add-uitableview-programmatically-in.html
//  URL:  https://www.murage.ca/downcasting-in-swift-1-2-with-as-exclamation/
//
//  @todo   pass delegate
//  @todo   pass datasource
//  @todo   make it be able to input N rows
//  @todo   set a row's background
//  @todo   set a row's text
//  @todo   make the clickability to a larger area!!! add 50% in -x, +x, -y, +y!
//  @todo   add a fade to the toggle of row text(s)!
//  @todo   toggle cell content on time or tap (color, text, etc). Takes a bit of work... :)
//  @todo   handle clicks! (e.g. UICheckBox.buttonClicked())
//              *You're going to need to store var access by fcn call

import UIKit

class ViewController: UIViewController {  
    
//    var items    : [String] = ["This Poo", "Table", "Works", "Well?", "Poo", "Kind Of???", "No", "Maybe", "Kind of", "Ok, you win"];

    var items : [String] = ["0", " 1", "  2", "   3", "    4", "     5", "      6", "       7", "        8", "         9", "          A"];
    
    var aNoteTable         : aNoteTableView!;
    var aNoteTableHandler : aNoteTableViewHandler!;
    
    //options
    var cellBordersVisible:Bool = true;
    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        print("ViewController.viewDidLoad():       entry");
        
        self.view.translatesAutoresizingMaskIntoConstraints = false;
        
        var tableFrame : CGRect = self.view.frame;
        
        tableFrame.origin.y = tableFrame.origin.y + 15;
    
        aNoteTable = aNoteTableView(frame:tableFrame, style:UITableViewStyle.Plain, items:items);
        
        //add the handler
        aNoteTableHandler = aNoteTableViewHandler(items: items, aNoteTable: aNoteTable);
        
        aNoteTable.delegate   = aNoteTableHandler;                                            //Set both to handle clicks & provide data
        aNoteTable.dataSource = aNoteTableHandler;
        
        //Add it!
        self.view.addSubview(aNoteTable);
        
        print("ViewController.viewDidLoad():       return");

        return;
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        return;
    }
}


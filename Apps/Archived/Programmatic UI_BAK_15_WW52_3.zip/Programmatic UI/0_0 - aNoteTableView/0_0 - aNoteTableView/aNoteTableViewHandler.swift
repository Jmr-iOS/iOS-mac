//
//  aNoteTableViewHandler.swift
//  0_0 - aNoteTableView
//
//

import UIKit


class aNoteTableViewHandler : NSObject, UITableViewDataSource, UITableViewDelegate {
   
    let verbose : Bool = true;
    
    var itemCount : Int!;
    
    var aNoteTable : aNoteTableView!;
    
    var items : [String]!;
    
    let nearColor:UIColor = UIColor(red: 255/255, green:  60/255, blue:  60/255, alpha: 1);
    let farColor :UIColor = UIColor(red: 210/255, green: 210/255, blue: 210/255, alpha: 1);//This shit is cut and pasted in MULTIPLE FILES. Edit with caution!!!

    
    init(items: [String], aNoteTable : aNoteTableView) {
        
        self.items = items;
        
        self.aNoteTable = aNoteTable;
        
        if(verbose){ print("aNoteTableViewHandler.init():       initialized"); }

        return;
    }
    
    
    func getCell(indexPath: NSIndexPath) -> aNoteTableViewCell {
  
        print("maybe?");
        print("woot woot");

        return aNoteTable.cellForRowAtIndexPath(indexPath) as! aNoteTableViewCell;
    }
    
    
    /****************************************************************************************************************************************/
    /*                                      UITableViewDataSource, UITableViewDelegate Interfaces                                           */
    /****************************************************************************************************************************************/
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if(verbose){ print("aNoteTableViewHandler.tableView():  The table will now have \(items.count), cause I just said so..."); }
        
        return items.count;                                                         //return how many rows you want printed....!
    }
    

    /************************************************************************************************************************************/
    /* @fcn       tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell                    */
    /* @details   add a cell to the table                                                                                               */
    /************************************************************************************************************************************/
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {

        print("add to index \(indexPath.item)??");
        let cell : aNoteTableViewCell = aNoteTable.dequeueReusableCellWithIdentifier("aNoteTableViewCell") as! aNoteTableViewCell!;

        cell.initialize(indexPath, aNoteTable: aNoteTable);
  
        return cell;
    }
    
    
    /************************************************************************************************************************************/
    /* @fcn       tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)                                     */
    /* @details   handle cell tap                                                                                                       */
    /************************************************************************************************************************************/
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
       
        if(true){ print("CustomTableViewHandler.tableView():         handling a cell tap of \(indexPath.item)"); }

        //CUSTOM
        aNoteTable.deselectRowAtIndexPath(indexPath, animated:true);
        
        //eww... the traditional access method...
        //let currCell : UICustomTableViewCell = customTable.dequeueReusableCellWithIdentifier("cell") as! UICustomTableViewCell;
        
        let cell : aNoteTableViewCell = self.getCell(indexPath);
        
        print("    We have cell '\( cell.textLabel?.text as String!)'");

        /********************************************************************************************************************************/
        /* scroll to the top or change the bar color                                                                                    */
        /********************************************************************************************************************************/
        switch(indexPath.row) {
        case (0):
            print("top selected. Scrolling to the bottom!");
            aNoteTable.scrollToRowAtIndexPath(NSIndexPath(forRow: items.count-1, inSection: 0), atScrollPosition: UITableViewScrollPosition.Bottom, animated: true);
            break;
        case (items.count-5):
            print("swapped the seperator color to red");
            aNoteTable.separatorColor = UIColor.redColor();
            break;
        case (items.count-4):
            print("swapped the seperator color to blue");
            aNoteTable.separatorColor = UIColor.blueColor();
            break;
        case (items.count-3):
            print("scrolling to the top with a Rect and fade");
            aNoteTable.scrollRectToVisible(CGRectMake(0,0,1,1), animated:true);           //slow scroll to top
            break;
        case (items.count-2):
            print("scrolling to the top with a Rect and no fade");
            aNoteTable.scrollRectToVisible(CGRectMake(0,0,1,1), animated:false);          //immediate scroll to top
            break;
        case (items.count-1):
            print("scrolling to the top with scrollToRowAtIndexPath");
            aNoteTable.scrollToRowAtIndexPath(NSIndexPath(forRow: 0, inSection: 0), atScrollPosition: UITableViewScrollPosition.Top, animated: true);
            break;
        default:
            print("I didn't program a reaction for this case. I was lazy...");
            break;
        }
        
        print("   ");
        
        return;
    }
}

//
//  aNoteTableViewCell.swift
//  0_0 - UITableView
//
//  @todo  make subjectField text wrap when it gets long. just takes a small bit sizing and placement, NBD!
//  @todo  use TWO diff grey colors for descr labels. Dark is normal, light is when cell is checked off and same as subject field color
//

import UIKit


class aNoteTableViewCell : UITableViewCell {
    
    let nearColor:UIColor = UIColor(red: 255/255, green:  60/255, blue:  60/255, alpha: 1);//This shit is cut and pasted in MULTIPLE FILES. Edit with caution!!!
    let farColor :UIColor = UIColor(red: 210/255, green: 210/255, blue: 210/255, alpha: 1);
    
    let aNoteRowHeight : CGFloat = 175;  //emperically chosen
    let checkBoxHeight : CGFloat = 40;   //all values
    let checkBox_xOffs : CGFloat = 20;   //This shit is cut and pasted in MULTIPLE FILES. Edit with caution!!!
    let cellOffs_Left  : CGFloat = 55;

    let verbose : Bool = false;

    
    var tableIndex : Int!;
    
    var checkBox  : UICheckbox!;
    
    var subjectField : UILabel!;
    var descripField : UILabel!;
    var bottField    : UILabel!;

    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style:style, reuseIdentifier:reuseIdentifier);
        
        if(verbose){ print("aNoteTableViewCell.init():          cell was initialized"); }
        
        return;
    }

    
    /************************************************************************************************************************************/
    /* @fcn       initialize(indexPath : NSIndexPath, aNoteTable : aNoteTableView)                                                      */
    /* @details   initialize the cell, after creation                                                                                   */
    /************************************************************************************************************************************/
    func initialize(indexPath : NSIndexPath, aNoteTable : aNoteTableView) {

        print("initialized!");
        
        let timeView_Width : CGFloat = 58;
        let timeView_xOffs : CGFloat = 300;

        let subjHeight : CGFloat = 25;
        let subjYOffs  : CGFloat = 25;
        
        let descripHeight: CGFloat = 20;
        let descripYOffs : CGFloat = subjYOffs + subjHeight;
        let bottYOffs    : CGFloat = descripYOffs + descripHeight;
        
        self.tableIndex = indexPath.item;
        
        /********************************************************/
        /* Checkbox                                             */
        /********************************************************/
        checkBox = UICheckbox(view:     self,
                                        parentCell: self,
                                        xCoord:     checkBox_xOffs,
                                        yCoord:     ((aNoteRowHeight-checkBoxHeight)/2)/2 - 9); //why div 2, div 2? hell if I know, emperically found!!!!
        
        self.addSubview(checkBox);
        
        /*******************************************************/
        /* Main(Subject) Text                                  */
        /*******************************************************/
        let rightScreenChunk_Width = UIScreen.mainScreen().bounds.width - timeView_xOffs - timeView_Width;
        
        let subjFieldWidth : CGFloat = UIScreen.mainScreen().bounds.width - cellOffs_Left - rightScreenChunk_Width;
        
        subjectField = UILabel(frame: CGRect(x:cellOffs_Left, y: 25, width: subjFieldWidth, height:  subjHeight));

        subjectField.text = aNoteTable.items[indexPath.item];
        subjectField.font = UIFont(name: self.textLabel!.font.fontName, size: 20);
        subjectField.textAlignment = NSTextAlignment.Left;
        print("maybe - \(subjectField.text!)");
        //TEMP
        //subjectField.backgroundColor = UIColor.blueColor();
        //END-TEMP
        
        self.addSubview(subjectField);
        
        
        /*******************************************************/
        /* Description Text                                    */
        /*******************************************************/
        let descrFieldWidth : CGFloat = UIScreen.mainScreen().bounds.width - cellOffs_Left - rightScreenChunk_Width;
        
        descripField = UILabel(frame: CGRect(x:cellOffs_Left, y: descripYOffs, width: descrFieldWidth, height:  descripHeight));
        
        descripField.text = aNoteTable.items[indexPath.item];
        descripField.font = UIFont(name: self.textLabel!.font.fontName, size: 14);
        descripField.textAlignment = NSTextAlignment.Left;
        descripField.textColor = UIColor.grayColor();
        
        
        //TEMP
        //descripField.backgroundColor = UIColor.greenColor();
        //END-TEMP
        
        self.addSubview(descripField);

        
        /*******************************************************/
         /* Description Text                                    */
         /*******************************************************/
        let boottFieldWidth : CGFloat = UIScreen.mainScreen().bounds.width - cellOffs_Left - rightScreenChunk_Width;
        
        bottField = UILabel(frame: CGRect(x:cellOffs_Left, y: bottYOffs, width: boottFieldWidth, height:  20));
        
        bottField.text = aNoteTable.items[indexPath.item];
        bottField.font = UIFont(name: self.textLabel!.font.fontName, size: 12);
        bottField.textAlignment = NSTextAlignment.Left;
        bottField.textColor = UIColor.grayColor();
        
        
        //TEMP
        //bottField.backgroundColor = UIColor.yellowColor();
        //END-TEMP
        
        self.addSubview(bottField);
        

        /********************************************************/
        /* Time Label                                           */
        /********************************************************/
        let timeView : UIView = UIView(frame: CGRect(x:timeView_xOffs, y: 15, width: timeView_Width, height:  20));        //values selected emperically
        
        timeView.backgroundColor = nearColor;
        timeView.layer.cornerRadius = 12;
        
        let timeLabel : UILabel = UILabel(frame: CGRect(x:9, y: 0, width: timeView.frame.width, height:  timeView.frame.height));
        
        timeLabel.font  =   UIFont(name: "HelveticaNeue", size: 10);
        timeLabel.text  =   "4:30 PM";
        timeLabel.textColor     = UIColor.whiteColor();
        timeLabel.textAlignment = NSTextAlignment.Left;
        
        timeView.addSubview(timeLabel);
        
        //add it
        self.addSubview(timeView);
        
        return;
    }
    
    func clickResponse() {
        
        
        //set the main text to the new color and state
        subjectField.textColor = (self.checkBox.state) ? UIColor.grayColor() : UIColor.blackColor();
        
        //strikethrough & font
        let newFontState : Int     = (self.checkBox.state) ? 2 : 0;

        let attributeString: NSMutableAttributedString =  NSMutableAttributedString(string: self.subjectField.text!);
        
        attributeString.addAttribute(NSStrikethroughStyleAttributeName, value: newFontState, range: NSMakeRange(0, attributeString.length))
        
        subjectField.attributedText = attributeString;

        if(verbose) { print("click. it's now \(self.checkBox.state)!"); }
        
        return;
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


//
//  UICheckBox.swift
//  0_0 - Checkbox
//
//  URL: http://stackoverflow.com/questions/2599451/cabasicanimation-delegate-for-animationdidstop
//

import UIKit

class UICheckbox: UIView {
    
    let verbose : Bool = false;
    
    var parentCell : aNoteTableViewCell!;
    
    var imageView : UIImageView!;

    var uncheckedImage  :UIImage = UIImage(named:"anote_unchecked")!;
    var checkedImage    :UIImage = UIImage(named:"anote_checked")!;
    
    let loadDelay_s   : Double  = 0.05;
    let uiCheckBoxDim : CGFloat = 40;
    
    var loadThread : NSTimer!;
    var fadeThread : NSTimer!;
    
    var state: Bool = false;
    
    init(view:UIView,/* mainView: UIView,*/ parentCell: aNoteTableViewCell, xCoord:CGFloat, yCoord:CGFloat) {

        super.init(frame:CGRectMake(xCoord, yCoord, (uiCheckBoxDim/2), (uiCheckBoxDim/2)));     //why %2? HECK IF I KNOW...!

        //image init
        imageView  = UIImageView();
        
        imageView.frame = CGRectMake(0, 0, (uiCheckBoxDim/2), (uiCheckBoxDim/2));
        
        imageView.image = uncheckedImage;

        //cell store
        self.parentCell = parentCell;
        
        //handle taps
        self.addTapRecognizer();

        //uiview setup: me<-image then main<-main
        self.addSubview(imageView);
        view.addSubview(self);
        
        if(verbose) { print("UICheckbox.init():                      complete"); }
        
        return;
    }


    func addTapRecognizer() {
        
        let tapRecognizer : UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "handleTap:");
        
        tapRecognizer.numberOfTapsRequired    = 1;
        tapRecognizer.numberOfTouchesRequired = 1;
        
        self.addGestureRecognizer(tapRecognizer);
        self.userInteractionEnabled = true;
        
        return;
    }

    
    func handleTap(recognizer:UITapGestureRecognizer) {
        
        //Swap w/Fade
        let fadeAnim:CABasicAnimation = CABasicAnimation(keyPath: "contents");
        
        fadeAnim.fromValue = (self.imageView.image == uncheckedImage) ? uncheckedImage:checkedImage;
        fadeAnim.toValue   = (self.imageView.image == uncheckedImage) ? checkedImage:uncheckedImage;
        
        fadeAnim.duration = loadDelay_s;
        
        fadeAnim.delegate = self;
        
        
        //Update ImageView & State
        state = (self.imageView.image == uncheckedImage) ? true : false;    //if it was unchecked, now it's checked, true!

        imageView.image = (self.imageView.image == uncheckedImage) ? checkedImage:uncheckedImage;
        
        imageView.layer.addAnimation(fadeAnim, forKey: "contents");

        
        //Handle the Click
        self.buttonClicked();
        
        return;
    }
    
    func buttonClicked() {

        print("UICheckbox.buttonClicked():    entry");
        
        //@todo   make the clickability to a larger area!!! add 50% in -x, +x, -y, +y!
        //@todo   add a fade to the toggle!
        //@note   you'll need to cross fade to a NEW view of the text!!! see link belo
        //@url    http://stackoverflow.com/questions/2426614/how-to-animate-the-textcolor-property-of-an-uilabel
        
        parentCell.clickResponse();
        
        print("\(parentCell.tableIndex) was clicked");
        return;
    }
    
    
    override func animationDidStop (anim: CAAnimation, finished flag: Bool) { return; }
    override func animationDidStart(anim: CAAnimation) { return; }
    
    
    required init?(coder aDecoder: NSCoder) { super.init(coder:aDecoder); }
}


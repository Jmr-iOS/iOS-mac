//
//  aNoteTableView.swift
//  0_0 - aNoteTableView
//
//
//  URL: http://www.ioscreator.com/tutorials/customizing-table-view-tutorial-in-ios8-with-swift
//  URL: https://grokswift.com/programmatic-uitableview-scrolling/
//

import UIKit

class aNoteTableView : UITableView {

    let aNoteRowHeight : CGFloat = 175;  //emperically chosen
    let checkBoxHeight : CGFloat = 40;   //all values
    let checkBox_xOffs : CGFloat = 20;   //This shit is cut and pasted in MULTIPLE FILES. Edit with caution!!!
    let cellOffs_Left  : CGFloat = 55;
      
    var items:[String]!;

    
    init(frame:CGRect, style:UITableViewStyle, items:[String]) {
        super.init(frame:frame, style:style);
        
        self.translatesAutoresizingMaskIntoConstraints = false;
        
        self.registerClass(aNoteTableViewCell.self, forCellReuseIdentifier: "aNoteTableViewCell");          //I have no idea why we do this
        self.translatesAutoresizingMaskIntoConstraints = false;                            //Std
        
        self.separatorColor = .grayColor();
        self.separatorStyle = .SingleLine;
        
        self.separatorInset = UIEdgeInsetsMake(0, cellOffs_Left, 0, 0);

        //Safety
        self.backgroundColor = UIColor.blackColor();
        
        //Set the row height
        self.rowHeight = (aNoteRowHeight/2);
        
        self.items = items;
        
        print("aNoteTableView.init:                aNote Table was initialized");
        
        return;
    }
    
    
    required init?(coder aDecoder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}


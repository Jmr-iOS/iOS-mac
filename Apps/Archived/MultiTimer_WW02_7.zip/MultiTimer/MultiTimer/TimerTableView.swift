/************************************************************************************************************************************/
/** @file		TimerTableView.swift
 *	@project    MultiTimer
 * 	@brief		x
 * 	@details	x
 *
 * 	@author		Justin Reina, Firmware Engineer, Vioteq
 * 	@created	1/6/16
 * 	@last rev	x
 *
 *
 * 	@notes		x
 *
 * 	@section	Opens
 * 			none current
 *
 * 	@section	Legal Disclaimer
 * 			All contents of this source file and/or any other Vioteq related source files are the explicit property on Vioteq
 * 			Corporation. Do not distribute. Do not copy.   Copyright © 2016 Jaostech. All rights reserved.
 */
/************************************************************************************************************************************/
import UIKit


class TimerTableView : UITableView {
    
    var mainView : UIView!;
    
    var myTimerCells : [TimerCell] = [TimerCell]();

    
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame:frame, style:style);
        
        self.registerClass(TimerCell.self, forCellReuseIdentifier: "cell");
        
        self.translatesAutoresizingMaskIntoConstraints = false;
        
        self.frame = CGRectMake(frame.origin.x,
                                frame.origin.y,
                                frame.width,
                                UIScreen.mainScreen().bounds.height);
        
        self.scrollEnabled = globals.mainTableScrollEnabled;
        
        if(verbose){ print("TimerTableView.init():                 the TimerTableView was initialized"); }
        
        return;
    }

    
    func initialize(initSize : Int, mainView : UIView) {

        print("(todo)TimerTableView.initialize():     Like, the whole thing...");
        
        self.mainView = mainView;
        
        //temp
        for i in 0...(numItems_init-1) {
            
            let newCell : TimerCell = TimerCell();

            newCell.initialize("Timer(\(i))", mainView: mainView);

            myTimerCells.append(newCell);
        }
       
        self.refreshTableHeight();

        return;
    }
    
    
    func refreshTableHeight() {
        
        self.reloadData();                              //update the data so the table is sized correctly for scrolling

        let newFrame : CGRect = CGRectMake(self.frame.origin.x,
                                           self.frame.origin.y,
                                           self.frame.width,
                                           globals.magicTableHeightMod*self.frame.height);
        
        self.frame = newFrame;
        
        return;
    }
    
    
    func addNewCell(cellTitle : String) -> TimerCell {
        
        
        let newCell : TimerCell = TimerCell(style: UITableViewCellStyle.Default, reuseIdentifier: cellTitle);

        newCell.initialize(cellTitle, mainView: mainView);
        
        //Add
        myTimerCells.append(newCell);

        self.reloadData();
        
        
        if(verbose){ print("TimerTableView.addCell():              a new cell was added"); }
        
        return newCell;
    }
    
    
    func removeCellAtIndex(index : Int) -> TimerCell {
        
        //grab
        let removedCell : TimerCell = myTimerCells[index];
    
        //remove
        myTimerCells.removeAtIndex(index);
    
        //update table (removes the 'Delete' bar)
        self.reloadData();
        
        
        return removedCell;
    }
    
    
    var deleteMode : Bool = false;
    
    
    func toggleDeleteMode() {
    
        self.deleteMode = !self.deleteMode;     // toggle
        
        self.setDelMode(self.deleteMode);    // apply the new mode val
        
    }
    
    
    func setDelMode(newMode : Bool) {

        print("I am going to '\(newMode)");

        self.deleteMode = newMode;                 // track mode
        
        self.setCellArrowState(!newMode);           //arrow is opposite of the delete button mode
        
        self.setEditing(newMode, animated: true);   // set mode
        
        
        return;
    }
    
    
    //******************************************************************************************************************************//
    //                                                  Helpers                                                                     //
    //******************************************************************************************************************************//
    func setCellArrowState(newState : Bool) {
        
        for i in 0...(myTimerCells.count-1) {

            self.myTimerCells[i].setArrowState(newState);
        }

        
        return;
    }
    
    
    func getCell(index: Int) -> TimerCell {
        
        let cell : TimerCell = self.myTimerCells[index];
        
        return cell;
    }


    func getCellCount() -> Int {
        return myTimerCells.count;
    }


    func getNumTimers() -> Int {
        return self.getCellCount();
    }

    
    required init?(coder aDecoder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}


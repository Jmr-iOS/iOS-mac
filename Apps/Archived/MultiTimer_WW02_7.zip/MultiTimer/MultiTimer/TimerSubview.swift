/************************************************************************************************************************************/
/** @file		TimerSubview.swift
 *	@project    MultiTimer
 * 	@brief		x
 * 	@details	x
 *
 * 	@author		Justin Reina, Firmware Engineer, Vioteq
 * 	@created	1/6/16
 * 	@last rev	x
 *
 *
 * 	@notes		x
 *
 * 	@section	Opens
 * 			none current
 *
 * 	@section	Legal Disclaimer
 * 			All contents of this source file and/or any other Vioteq related source files are the explicit property on Vioteq
 * 			Corporation. Do not distribute. Do not copy.   Copyright © 2016 Jaostech. All rights reserved.
 */
/************************************************************************************************************************************/
import UIKit



class TimerSubview : UIView {
    
    var parentCell : TimerCell!;

    var clearButton  : UIButton!;
    var returnButton : UIButton!;

    
    init(frame: CGRect, cell: TimerCell) {
        super.init(frame:frame);
            
        self.parentCell = cell;
            
        self.backgroundColor = UIColor.whiteColor();
        
        //add 'Clear'
        clearButton = UIButton(type: UIButtonType.RoundedRect);
        clearButton.translatesAutoresizingMaskIntoConstraints = true;                                  //must be true for center to work
        clearButton.setTitle("Clear",      forState: UIControlState.Normal);
        clearButton.sizeToFit();
        clearButton.center = CGPointMake(self.frame.width/2, 100 + 4);
        clearButton.addTarget(self, action: "clearPressed:", forControlEvents:  .TouchUpInside);
        
        self.addSubview(clearButton);
            
        
        //add 'Return'
        returnButton = UIButton(type: UIButtonType.RoundedRect);
        returnButton.translatesAutoresizingMaskIntoConstraints = true;                                  //must be true for center to work
        returnButton.setTitle("Return",      forState: UIControlState.Normal);
        returnButton.sizeToFit();
        returnButton.center = CGPointMake(self.frame.width/2, clearButton.frame.origin.y + 50 + 2);
        returnButton.addTarget(self, action: "returnPressed:", forControlEvents:  .TouchUpInside);
        
        self.addSubview(returnButton);

        let activeTime : TimeLogValue!   = self.parentCell.activeTime;
        var timeLog    : [TimeLogValue]! = self.parentCell.timeLog;
        
        if(timeLog==nil) { timeLog = [TimeLogValue](); }
        
        
        //add (temporary) Active Label (placeholder for real deal)
        let aFrame : CGRect = CGRectMake(50, 100, UIScreen.mainScreen().bounds.width, 50);
        
        let a : UILabel = UILabel(frame: aFrame);
        
        if(activeTime != nil) {
            a.text = TimeLogValue.getPrintString(TimeLogValue.getTimeForPrint(activeTime)());
        } else {
            a.text = "00:00:00";
        }
        a.numberOfLines = 1;
       
        self.addSubview(a);
        
        
        //add (temporary) Log Label (placeholder for TableView)
        let lFrame : CGRect = CGRectMake(50, 200, UIScreen.mainScreen().bounds.width, 500);
        
        let l : UILabel = UILabel(frame: lFrame);
        
        var logText = "";
        
        for(var i=0; i<timeLog.count; i++) {

            let currVal : TimeLogValue = timeLog[i];
            
            let currTime : TimeValue = currVal.getTimeForPrint();
            
            logText = logText + "\n" + TimeLogValue.getPrintString(currTime);
        }
        
        l.text = logText;
        l.numberOfLines = timeLog.count + 1; //why +1???
        
        self.addSubview(l);
        
        
        return;
    }
        
    
    func resetPressed(sender: UIButton!) {
            
        parentCell.resetTimer();
        
        self.removeFromSuperview();
        
        return;
    }
    
    
    func clearPressed(sender: UIButton!) {
            
        parentCell.clearTimer();
        
        self.removeFromSuperview();
        
        return;
    }
    
    
    func returnPressed(sender: UIButton!) {
        
        if(verbose) { print("\(sender.titleLabel!.text!) was pressed"); }
        
        self.removeFromSuperview();
        
        return;
    }
        
    
    required init?(coder aDecoder: NSCoder) { fatalError("init(coder:) has not been implemented"); }
}


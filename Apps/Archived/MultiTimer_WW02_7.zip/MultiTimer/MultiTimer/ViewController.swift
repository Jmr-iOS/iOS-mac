/************************************************************************************************************************************/
 /**@file		ViewController.swift
 *  @project    MultiTimer
 * 	@author		Justin Reina, Firmware Engineer, Vioteq
 *
 * 	@notes		x
 *
 * 	@section	Opens
 * 			Shown in each TimerCell's SubView
 *           - Title & Subtitle per Timer (editable)
 *           - Notes section (editable)
 *           - Log of times
 *          Icon
 *          TimerSubview Log Table is an actual table!
 *          TimerSubview has a clean active time value that is colored correctly and updates in user-real-time
 *          EVERY function has a header in this project
 *          Everything is cleanly and clearly commented (consider that this is your first App!)
 *          ALL files have clear headers! and fully filled out!
 *
 * 	@section	Legal Disclaimer
 * 			All contents of this source file and/or any other Vioteq related source files are the explicit property on Vioteq
 * 			Corporation. Do not distribute. Do not copy.
 */
/************************************************************************************************************************************/

import UIKit

class ViewController: UIViewController {

    //todo: toss grety bary on titleLabel here too
    var remButton          : UIButton!;                                             /* Remove Button on Upper Left                  */
    var addButton          : UIButton!;                                             /* Add('+') Button on Upper Right               */
    var titleBarLabel      : UILabel!;                                              /* Entire Title Bar                             */
    var titleBarBottBorder : UIView!;                                               /* Grey Border at bottom of Title Bar           */
    var timerTable         : TimerTableView!;
    var timerTableHandler  : TimerTableHandler!;

    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        self.view.translatesAutoresizingMaskIntoConstraints = false;
        
        
        //UI Init
        self.initTitleBar();
        self.initAddButton();
        self.initRemButton();
        self.initTimerTable();
        
        
        //Exit
        if(verbose){ print("ViewController.viewDidLoad():          viewDidLoad() complete"); }
        
        return;
    }
    

    func initTitleBar() {
        
        self.titleBarLabel = UILabel(frame: CGRectMake(0, globals.titleBarYOffs, UIScreen.mainScreen().bounds.width, globals.titleBarHeight));
        
        self.titleBarLabel.text = "Timers";
        
        self.titleBarLabel.textAlignment = .Center;
        
        self.titleBarLabel.font = globals.titleBarFont;
        
        self.view.addSubview(self.titleBarLabel);
        
        
        //add bottom border
        titleBarBottBorder = UIView(frame: CGRectMake(0, globals.titleBarYOffs+self.titleBarLabel.frame.height-1, UIScreen.mainScreen().bounds.width, 1));
        
        titleBarBottBorder.backgroundColor = UIColor.grayColor();
        
        self.view.addSubview(titleBarBottBorder);
        

        return;
    }
    
    
    func initAddButton() {
        self.addButton = UIButton(frame: CGRectMake(globals.addLabelXOffs, globals.addLabelYOffs, 20, 30));
        
        self.addButton.setTitle("+", forState:  .Normal);
        
        self.addButton.setTitleColor(UIColor.redColor(), forState: .Normal);
        
        self.addButton.titleLabel!.font =  self.addButton.titleLabel!.font.fontWithSize(globals.addFontSize);
        
        self.addButton.titleLabel!.font = globals.titleBarFont;
        
        self.addButton.addTarget(self, action: "addTimer:", forControlEvents:  .TouchUpInside);
        
        self.view.addSubview(self.addButton);
        
        
        return;
    }
    
    
    func initRemButton() {
        
        self.remButton = UIButton(frame: CGRectMake(globals.remLabelXOffs, globals.remLabelYOffs, 100, 30));
        
        self.remButton.setTitle("Edit", forState:  .Normal);
        
        self.remButton.setTitleColor(UIColor.redColor(), forState: .Normal);
        
        self.remButton.titleLabel!.font =  self.remButton.titleLabel!.font.fontWithSize(globals.remFontSize);
        
        self.addButton.titleLabel!.font = globals.titleBarFont;
        
        self.remButton.addTarget(self, action: "editButtonResponse:", forControlEvents:  .TouchUpInside);
        
        self.view.addSubview(self.remButton);
        
        return;
    }

    
    func initTimerTable() {
    
        if(verbose){ print("ViewController.addTimerTable():        adding the timer table"); }
        
        print("(todo)ViewController.initTimerTable(): timerTable Frame");
        
        let timerTableFrame : CGRect = CGRect(x:      0,
                                              y:      self.titleBarLabel.frame.origin.y + self.titleBarLabel.frame.height,
                                              width:  UIScreen.mainScreen().bounds.width,
                                              height: UIScreen.mainScreen().bounds.width);
        
        timerTable = TimerTableView(frame:timerTableFrame, style:UITableViewStyle.Plain);
        
        timerTable.initialize(numItems_init, mainView: self.view);
        
        
        //add the handler
        timerTableHandler = TimerTableHandler(timerTable: self.timerTable, mainView:  self.view, viewController: self);
        
        timerTable.delegate   = timerTableHandler;                                    /* Set both to handle clicks & provide data  */
        timerTable.dataSource = timerTableHandler;
        
        //init the table
        timerTable.separatorColor = .grayColor();
        timerTable.separatorStyle = .SingleLine;
        
        //Safety
        timerTable.backgroundColor = UIColor.whiteColor();
        
        //Set the row height
        timerTable.rowHeight = globals.tableRowHeight;
        
        if(verbose){ print("ViewController.addTimerTable():        it was shown"); }
        
        self.view.addSubview(timerTable);
        
        
        return;
    }
    
    
    func addTimer(sender: UIButton!) {
        
        self.timerTable.addNewCell("Test Label");
        
        self.timerTable.reloadData();
        self.timerTable.sizeToFit();
        
        //Not sure why I have to redo the frame - EWWW/WHATEV - it works so...
        let newCt : CGFloat = CGFloat(self.timerTable.getCellCount());
        let newFrame : CGRect = CGRectMake(self.timerTable.frame.origin.x,
                                           self.timerTable.frame.origin.y,
                                           UIScreen.mainScreen().bounds.width,
                                           newCt*globals.tableRowHeight);
        
        self.timerTable.frame = newFrame;
        
        //Turn off delete mode (awk for User if u don't)
        self.timerTable.setDelMode(false);

        if(verbose){ print("ViewController.addTimer():             timer was added to the table"); }
        
        return;
    }
    
    
    func editButtonResponse(sender: UIButton!) {

        self.timerTable.toggleDeleteMode();                     /* toggle the mode & apply                                          */
        
        if(verbose){ print("ViewController.removeTimer():          added timer was removed from the table"); }
        
        return;
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning();
        return;
    }
}


/************************************************************************************************************************************/
/** @file		TimeLogValue.swift
 *	@project    MultiTimer
 * 	@brief		x
 * 	@details	x
 *
 * 	@author		Justin Reina, Firmware Engineer, Vioteq
 * 	@created	1/10/16
 * 	@last rev	x
 *
 *
 * 	@notes		x
 *
 * 	@section	Opens
 * 			none current
 *
 * 	@section	Legal Disclaimer
* 			All contents of this source file and/or any other Vioteq related source files are the explicit property on Vioteq
* 			Corporation. Do not distribute. Do not copy.   Copyright © 2016 Jaostech. All rights reserved.
 */
/************************************************************************************************************************************/
import UIKit

struct TimeValue {
    var years        : Int = 0;
    var months       : Int = 0;
    var days         : Int = 0;
    var hours        : Int = 0;
    var minutes      : Int = 0;
    var seconds      : Int = 0;
    var milliseconds : Int = 0;
}

class TimeLogValue : NSObject {
    
    var start : NSDate!;
    var end   : NSDate!;
    
    
    /********************************************************************************************************************************/
    /*	@fcn		override init()                                                                                                 */
    /*  @brief      explicitly leave start and stop nil, uninitialized                                                              */
    /********************************************************************************************************************************/
    override init() {
        super.init();
        
        self.start = nil;           //not initialized
        self.end   = nil;           //not initialized
        
        return;
    }


    init(totalDur_s : Double) {
        super.init();
        
        self.start = NSDate(timeIntervalSinceNow: 0);
        self.end   = NSDate(timeIntervalSinceNow: totalDur_s);
        
        return;
    }
    
    
    /********************************************************************************************************************************/
    /*	@fcn		isRunning() -> Bool                                                                                             */
    /********************************************************************************************************************************/
    func isRunning() -> Bool {
        
        if(start == nil) {
            return false;                       //not yet started
        }
        
        if(start != nil) && (end != nil) {
            return false;                       // all done!
        }
        
        return true;                            // started but not yet done!
    }
    
    
    /********************************************************************************************************************************/
    /*	@fcn		startTimeLogValue()                                                                                             */
    /*  @brief		start it running (start initialized, end is nil)                                                                */
    /********************************************************************************************************************************/
    func startTimeLogValue() {
    
        self.start = NSDate(timeIntervalSinceNow: 0);
        self.end   = nil;
        
        return;
    }
    
    
    /********************************************************************************************************************************/
    /*	@fcn		stopTimeLogValue()                                                                                              */
    /*  @brief		stop it (just update end)                                                                                       */
    /********************************************************************************************************************************/
    func stopTimeLogValue() {
        
        self.end = NSDate(timeIntervalSinceNow: 0);
        
        return;
    }
    
    
    /********************************************************************************************************************************/
    /*	@fcn		getTime_s() -> Double                                                                                           */
    /*  @brief		return the time value for this log value (three cases, take a peek!)                                            */
    /********************************************************************************************************************************/
    func getTime_s() -> Double {
        
        //is start nil?
        if(start == nil) {
            return 0;
        }
        
        //is end nil?
        if(end == nil) {
            
            let currTime : NSDate = NSDate(timeIntervalSinceNow: 0);        //then use curr time
            
            return currTime.timeIntervalSinceDate(start);
        }
        
        //all valid!
        return end.timeIntervalSinceDate(start);
    }


//**********************************************************************************************************************************//
//																Helpers                                                             //
//**********************************************************************************************************************************//
    class func test() -> Int {
        return 0;
    }
    
    class func calcTotal(value : TimeLogValue!, vals : [TimeLogValue]!) -> TimeLogValue {

        var totalDur_s : Double = 0;
        
        if(value != nil) {
            totalDur_s = totalDur_s + value.getTime_s();
        }
        
        if(vals != nil) {
            for(var i = 0; i < vals.count; i++) {

                totalDur_s = totalDur_s + vals[i].getTime_s();
            }
        }
        
        
        let t : TimeLogValue = TimeLogValue(totalDur_s: totalDur_s);
        
        return t;
    }
    
    
    func getTimeForPrint() -> TimeValue {
        
        var timeVal : TimeValue = TimeValue();
        
        var runningTotal_s : Double = self.getTime_s();
        
        //Years
        let numYears : Int = Int(runningTotal_s / Double(NUM_SEC_IN_YEAR));         //calc
        
        runningTotal_s = runningTotal_s - (Double(numYears*NUM_SEC_IN_YEAR));       //adjust

        //Months
        let numMonths : Int = Int(runningTotal_s / Double(NUM_SEC_IN_MONTH));       //calc
        
        runningTotal_s = runningTotal_s - (Double(numMonths*NUM_SEC_IN_MONTH));     //adjust

        //Days
        let numDays : Int = Int(runningTotal_s / Double(NUM_SEC_IN_DAY));           //calc
        
        runningTotal_s = runningTotal_s - (Double(numDays*NUM_SEC_IN_DAY));         //adjust
        
        //Hours
        let numHours : Int = Int(runningTotal_s / Double(NUM_SEC_IN_HOUR));         //calc
        
        runningTotal_s = runningTotal_s - (Double(numHours*NUM_SEC_IN_HOUR));       //adjust

        //Minutes
        let numMinutes : Int = Int(runningTotal_s / Double(NUM_SEC_IN_MINUTE));     //calc
        
        runningTotal_s = runningTotal_s - (Double(numMinutes*NUM_SEC_IN_MINUTE));   //adjust

        //Seconds
        let numSeconds : Int = Int(runningTotal_s / Double(NUM_SEC_IN_SECOND));     //calc
        
        runningTotal_s = runningTotal_s - (Double(numSeconds*NUM_SEC_IN_SECOND));   //adjust

        //Milliseconds
        let numMilliseconds : Int = Int(runningTotal_s * Double(NUM_MS_IN_SECOND)); //calc
        
        //Safeties
        if(numMonths > NUM_MONTHS_IN_YEAR) { fatalError("TimeLogValue.getTimeForPrint(): Time Value was calculated wrong, coding error on milliseconds - (\(numMilliseconds))"); }
        if(numDays > NUM_DAYS_IN_MONTH_MAX) { fatalError("TimeLogValue.getTimeForPrint(): Time Value was calculated wrong, coding error on milliseconds - (\(numMilliseconds))"); }
        if(numHours > NUM_HOURS_IN_DAY) { fatalError("TimeLogValue.getTimeForPrint(): Time Value was calculated wrong, coding error on milliseconds - (\(numMilliseconds))"); }
        if(numMinutes > NUM_MIN_IN_HOUR) { fatalError("TimeLogValue.getTimeForPrint(): Time Value was calculated wrong, coding error on milliseconds - (\(numMilliseconds))"); }
        if(numSeconds > NUM_SEC_IN_MINUTE) { fatalError("TimeLogValue.getTimeForPrint(): Time Value was calculated wrong, coding error on milliseconds - (\(numMilliseconds))"); }
        if(numMilliseconds > NUM_MS_IN_SECOND) { fatalError("TimeLogValue.getTimeForPrint(): Time Value was calculated wrong, coding error on milliseconds - (\(numMilliseconds))"); }

        //Store
        timeVal.years = numYears;
        timeVal.months = numMonths;
        timeVal.days = numDays;
        timeVal.hours = numHours;
        timeVal.minutes = numMinutes;
        timeVal.seconds = numSeconds;
        timeVal.milliseconds = numMilliseconds;
        
        
        return timeVal;
    }

    
    class func getPrintString(val : TimeValue) -> String {

        let returnStr : String = String(format: "%.2d:%.2d.%.2d", val.minutes, val.seconds, val.milliseconds/10);       //div by 10 for 2 digs

        return returnStr;
    }
}


/************************************************************************************************************************************/
/** @file		TimerTableHandler.swift
 *	@project    MultiTimer
 * 	@brief		x
 * 	@details	x
 *
 * 	@author		Justin Reina, Firmware Engineer, Vioteq
 * 	@created	1/6/16
 * 	@last rev	x
 *
 *
 * 	@notes		x
 *
 * 	@section	Opens
 * 			none current
 *
 * 	@section	Legal Disclaimer
* 			All contents of this source file and/or any other Vioteq related source files are the explicit property on Vioteq
* 			Corporation. Do not distribute. Do not copy.   Copyright © 2016 Jaostech. All rights reserved.
 */
/************************************************************************************************************************************/
import UIKit


class TimerTableHandler : NSObject, UITableViewDataSource, UITableViewDelegate {
    
    
    var mainView   : UIView!;
    var timerTable : TimerTableView!;
    var vc         : ViewController!;
    
    var editMode : Bool = false;            //is the table in '-' delete mode?
    
    
    init(timerTable : TimerTableView, mainView : UIView, viewController : ViewController) {
        
        self.mainView   = mainView;
        self.timerTable = timerTable;
        self.vc         = viewController;
        
        if(verbose){ print("TimerTableViewHandler.init():          the TimerTableViewHandler was initialized"); }
        
        return;
    }
    
    
    /********************************************************************************************************************************/
    //													UITableViewDataSource														 *
    //*******************************************************************************************************************************/
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int  {
        
        if(verbose){ print("TimerTableViewHandler.tableView():     (cellForRow) The table will now have \(self.timerTable.getCellCount()), cause I just said so..."); }
        
        return self.timerTable.getCellCount();
    }

    
    func tableView(tableView: UITableView,  cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell : TimerCell = self.timerTable.myTimerCells[indexPath.item];

        if(verbose){ print("TimerTableHandler.tableview():         (cellForRow) '\(cell.timerName)' was added to the table"); }
        
        return cell;
    }
    
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true;
    }
    
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {

        if (editingStyle == UITableViewCellEditingStyle.Delete) {

            self.timerTable.removeCellAtIndex(indexPath.item);                          /* removed!                                 */
        }

        return;
    }

    
    /********************************************************************************************************************************/
    //													UITableViewDelegate                                                          *
    //*******************************************************************************************************************************/
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        if(true){ print("TimerTableViewHandler.tableView():     handling a cell tap of \(indexPath.item)"); }
        
        //CUSTOM
        timerTable.deselectRowAtIndexPath(indexPath, animated:true);
     
        if(self.timerTable.getNumTimers() > 0) {
            let cell : TimerCell = self.timerTable.getCell(indexPath.item);
            cell.toggleTimer();
        }
        
        print("   ");
    
        return;
    }
}


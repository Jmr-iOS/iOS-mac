//
//  ViewController.swift
//  TableView Example
//
//  URL:  http://viperxgames.blogspot.com/2014/11/add-uitableview-programmatically-in.html
//  URL:  https://www.murage.ca/downcasting-in-swift-1-2-with-as-exclamation/
//
//  todo: pass delegate
//  todo: pass datasource
//  todo: make it be able to input N rows
//  todo: set a row's background
//  todo: set a row's text
//


import UIKit

class ViewController: UIViewController {  
    
    var items    : [String] = ["This Poo", "Table", "Works", "Well?", "Poo", "Kind Of???", "No", "Maybe", "Kind of", "Ok, you win"];

    var aNoteTable:aNoteTableView!;
    
    //options
    var cellBordersVisible:Bool = true;
    
    override func viewDidLoad() {
        super.viewDidLoad();

        self.view.translatesAutoresizingMaskIntoConstraints = false;
        
        aNoteTable = aNoteTableView(frame:self.view.frame, style:UITableViewStyle.Plain, items:items);
        
        //Add it!
        self.view.addSubview(aNoteTable);
        
        return;
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        return;
    }
}


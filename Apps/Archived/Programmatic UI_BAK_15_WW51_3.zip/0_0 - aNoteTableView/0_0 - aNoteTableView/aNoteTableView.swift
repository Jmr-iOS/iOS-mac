//
//  aNoteTableView.swift
//  0_0 - aNoteTableView
//
//
//  URL: http://www.ioscreator.com/tutorials/customizing-table-view-tutorial-in-ios8-with-swift
//  URL: https://grokswift.com/programmatic-uitableview-scrolling/
//

import UIKit

class aNoteTableView : UITableView, UITableViewDelegate, UITableViewDataSource {

    var cellBordersVisible:Bool = true;
    
    var items:[String]!;
    
    init(frame:CGRect, style:UITableViewStyle, items:[String]) {
        super.init(frame:frame, style:style);

        self.translatesAutoresizingMaskIntoConstraints = false;
        
        self.delegate      =   self;
        self.dataSource    =   self;
        
        self.registerClass(UITableViewCell.self, forCellReuseIdentifier: "cell");          //I have no idea why we do this
        self.translatesAutoresizingMaskIntoConstraints = false;                            //Std
        
        self.separatorColor = (cellBordersVisible) ? .greenColor() : .clearColor();
        self.separatorStyle = (cellBordersVisible) ? .SingleLine : .None;
        
        //Safety
        self.backgroundColor = UIColor.blackColor();
        
        //Set the row height
        self.rowHeight = 75;
        
        self.items = items;
        
        print("aNote Table was initialized");
        
        return;
    }
    
    

/****************************************************************************************************************************************/
/*                                      UITableViewDataSource, UITableViewDelegate Interfaces                                           */
/****************************************************************************************************************************************/
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //print("ViewController.tableView():         The table will now have \(items.count), cause I just said so...");
        
        return items.count;                                                         //return how many rows you want printed....!
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell:UITableViewCell = tableView.dequeueReusableCellWithIdentifier("cell") as UITableViewCell!;
        
        let newTextValue:String = self.items[indexPath.row];
        
        cell.addSubview(UICheckbox(view: self, xCoord: 30, yCoord: 17));
            
        cell.textLabel?.text = newTextValue;                                                //text
        cell.textLabel?.font = UIFont(name: cell.textLabel!.font.fontName, size: 20);       //font
        cell.textLabel?.textAlignment = NSTextAlignment.Center;                             //alignment
        
        //print("'\(newTextValue)' was added to the table");
        
        return cell;
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        tableView.deselectRowAtIndexPath(indexPath, animated:true);
       
        /********************************************************************************************************************************/
        /* scroll to the top or change the bar color                                                                                    */
        /********************************************************************************************************************************/
        switch(indexPath.row) {
            case (0):
                print("top selected. Scrolling to the bottom!");
                self.scrollToRowAtIndexPath(NSIndexPath(forRow: items.count-1, inSection: 0), atScrollPosition: UITableViewScrollPosition.Bottom, animated: true);
                break;
            case (items.count-5):
                print("swapped the seperator color to red");
                tableView.separatorColor = UIColor.redColor();
                break;
            case (items.count-4):
                print("swapped the seperator color to blue");
                tableView.separatorColor = UIColor.blueColor();
                break;
            case (items.count-3):
                print("scrolling to the top with a Rect and fade");
                self.scrollRectToVisible(CGRectMake(0,0,1,1), animated:true);           //slow scroll to top
                break;
            case (items.count-2):
                print("scrolling to the top with a Rect and no fade");
                self.scrollRectToVisible(CGRectMake(0,0,1,1), animated:false);          //immediate scroll to top
                break;
            case (items.count-1):
                print("scrolling to the top with scrollToRowAtIndexPath");
                self.scrollToRowAtIndexPath(NSIndexPath(forRow: 0, inSection: 0), atScrollPosition: UITableViewScrollPosition.Top, animated: true);
                break;
        default:
            print("I didn't program a reaction for this case. I was lazy...");
            break;
        }
        
        return;
    }

    required init?(coder aDecoder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}
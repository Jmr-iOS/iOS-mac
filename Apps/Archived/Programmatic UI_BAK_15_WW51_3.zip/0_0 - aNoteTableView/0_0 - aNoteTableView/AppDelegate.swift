//
//  AppDelegate.swift
//  TableView Example
//
//  Created by Justin Reina on 11/15/15.
//  Copyright © 2015 Jaostech. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        
        self.window = UIWindow.init(frame: UIScreen.mainScreen().bounds);
        
        self.window?.backgroundColor = UIColor.whiteColor();
        
        let viewController:ViewController = ViewController();
        
        viewController.view.translatesAutoresizingMaskIntoConstraints = false;
        
        self.window?.rootViewController = viewController;
        
        self.window?.makeKeyAndVisible();
        
        print("AppDelegate.application():          Application launch complete");
        print(" ");

        return true;
    }
    
    func applicationWillResignActive(application   : UIApplication) {return;}
    func applicationDidEnterBackground(application : UIApplication) {return;}
    func applicationWillEnterForeground(application: UIApplication) {return;}
    func applicationDidBecomeActive(application    : UIApplication) {return;}
    func applicationWillTerminate(application      : UIApplication) {return;}
}

